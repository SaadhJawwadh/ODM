declare global {
    var activeDownloads: Map<string, any> | undefined
}

export { }