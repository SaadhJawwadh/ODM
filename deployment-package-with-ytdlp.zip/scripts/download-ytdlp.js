const { createWriteStream, mkdirSync, existsSync, chmodSync } = require('fs');
const { join } = require('path');
const { finished } = require('stream/promises');
const https = require('https');
const http = require('http');

const binDir = join(process.cwd(), 'bin');

function getPlatformInfo() {
    const platform = process.platform;
    const arch = process.arch;

    if (platform === 'win32') {
        return {
            name: 'yt-dlp.exe',
            url: 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe',
        };
    }

    if (platform === 'linux') {
        return {
            name: 'yt-dlp',
            url: 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp',
        };
    }

    if (platform === 'darwin') {
        return {
            name: 'yt-dlp_macos',
            url: 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp_macos',
        };
    }

    throw new Error(`Unsupported platform: ${platform}`);
}

function downloadFile(url, path) {
    return new Promise((resolve, reject) => {
        console.log(`📥 Downloading yt-dlp from ${url}...`);

        if (!existsSync(binDir)) {
            mkdirSync(binDir, { recursive: true });
        }

        const protocol = url.startsWith('https:') ? https : http;
        const fileStream = createWriteStream(path, { mode: 0o755 });

        const request = protocol.get(url, (response) => {
            if (response.statusCode !== 200) {
                reject(new Error(`HTTP ${response.statusCode}: ${response.statusMessage}`));
                return;
            }

            response.pipe(fileStream);

            fileStream.on('finish', () => {
                fileStream.close();
                if (process.platform !== 'win32') {
                    chmodSync(path, 0o755);
                }
                console.log(`✅ yt-dlp downloaded successfully to ${path}`);
                resolve(true);
            });
        });

        request.on('error', (error) => {
            reject(error);
        });

        fileStream.on('error', (error) => {
            reject(error);
        });
    });
}

async function main() {
    console.log('🚀 Starting yt-dlp download for deployment...');

    const platformInfo = getPlatformInfo();
    const localPath = join(binDir, platformInfo.name);

    // Check if already exists
    if (existsSync(localPath)) {
        console.log(`✅ yt-dlp already exists at ${localPath}`);
        return;
    }

    try {
        // Download yt-dlp
        await downloadFile(platformInfo.url, localPath);
        console.log('🎉 yt-dlp is ready for deployment!');
    } catch (error) {
        console.error(`❌ Failed to download yt-dlp:`, error.message);
        console.log('⚠️  yt-dlp download failed. The app will attempt to download it at runtime.');
    }
}

// Run the script
main().catch(console.error);