# Deployment Guide

## Overview
This application includes an embedded `yt-dlp` binary that ensures video downloading works reliably across different hosting environments.

## Pre-deployment Setup

### 1. Download yt-dlp Binary
Before deploying, run the following command to download the appropriate `yt-dlp` binary for your target platform:

```bash
npm run download-ytdlp
```

This will create a `bin/` directory with the appropriate binary:
- **Windows**: `bin/yt-dlp.exe`
- **Linux**: `bin/yt-dlp`
- **macOS**: `bin/yt-dlp_macos`

### 2. Build the Application
```bash
npm run build
```

The build process will automatically run the yt-dlp download script if it hasn't been run yet.

## Deployment Options

### Option 1: DirectAdmin with NodeJS Selector

1. **Upload Files**: Upload the entire project directory to your server
2. **Install Dependencies**: Run `npm install` in the NodeJS Selector
3. **Build Application**: Run `npm run build`
4. **Start Application**: Set startup file to `server.js` and start the app

### Option 2: VPS/Dedicated Server

1. **Clone/Upload**: Get the code to your server
2. **Install Dependencies**: `npm install`
3. **Download yt-dlp**: `npm run download-ytdlp`
4. **Build**: `npm run build`
5. **Start**: `npm start`

### Option 3: Docker Deployment

Create a `Dockerfile`:

```dockerfile
FROM node:18-alpine

WORKDIR /app

# Install dependencies
COPY package*.json ./
RUN npm install

# Copy source code
COPY . .

# Download yt-dlp for Linux
RUN npm run download-ytdlp

# Build the application
RUN npm run build

# Expose port
EXPOSE 3000

# Start the application
CMD ["npm", "start"]
```

## Platform-Specific Notes

### Linux Servers
- The `yt-dlp` binary will be automatically downloaded for Linux
- Ensure the binary has execute permissions: `chmod +x bin/yt-dlp`
- The application will use the local binary by default

### Windows Servers
- The `yt-dlp.exe` binary will be downloaded
- No additional configuration needed

### CloudLinux/Shared Hosting
- The embedded binary approach ensures compatibility
- No system-wide installation required
- Works with restricted environments

## Troubleshooting

### yt-dlp Not Found
If you see "yt-dlp not found" errors:

1. **Check Binary**: Ensure `bin/yt-dlp` (or `bin/yt-dlp.exe` on Windows) exists
2. **Permissions**: On Linux, ensure the binary is executable: `chmod +x bin/yt-dlp`
3. **Manual Download**: Run `npm run download-ytdlp` manually

### Permission Errors
If you get permission errors:

```bash
# On Linux/macOS
chmod +x bin/yt-dlp

# On Windows (if needed)
icacls bin\yt-dlp.exe /grant Everyone:F
```

### Binary Not Working
If the binary doesn't work:

1. **Check Architecture**: Ensure you're using the correct binary for your platform
2. **Dependencies**: Some systems may need additional libraries
3. **Fallback**: The app will attempt to download a fresh copy at runtime

## File Structure After Deployment

```
your-app/
├── bin/
│   ├── yt-dlp (Linux/macOS) or yt-dlp.exe (Windows)
├── src/
├── .next/
├── package.json
├── server.js
└── ... (other files)
```

## Security Considerations

- The `bin/` directory contains executable files
- Ensure proper file permissions on the server
- The binary is downloaded from the official yt-dlp GitHub releases
- Consider scanning the binary with your security tools if required

## Updates

To update yt-dlp to the latest version:

1. **Via UI**: Use the "Update" button in the settings
2. **Via Command**: Run `npm run download-ytdlp` to force a fresh download
3. **Manual**: Delete `bin/yt-dlp*` and run the download script again

## Support

If you encounter issues:

1. Check the application logs for detailed error messages
2. Verify the yt-dlp binary exists and is executable
3. Test with a simple YouTube URL first
4. Check your hosting provider's restrictions on file downloads